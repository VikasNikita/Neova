package com.java.container;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class ArrayListTest {

	public static void main(String[] args) {
		Phonelog phonelog=new Phonelog("Nikita","missed", LocalDateTime.now());
		Phonelog phonelog2=new Phonelog("Rupali","missed", LocalDateTime.now());
		Phonelog phonelog3=new Phonelog("Shraddha","missed", LocalDateTime.now());
		Phonelog phonelog4=new Phonelog("Sana","missed", LocalDateTime.now());
		Phonelog phonelog5=new Phonelog("Gitika","missed", LocalDateTime.now());
		
		ArrayList<Phonelog> myphoneloglist=new ArrayList<Phonelog>();
		System.out.println("Container is ready.....");
		
		myphoneloglist.add(phonelog);
		myphoneloglist.add(phonelog2);
		myphoneloglist.add(phonelog3);
		myphoneloglist.add(phonelog4);
		myphoneloglist.add(phonelog5);
		
		
		
	}

}
