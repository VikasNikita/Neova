package com.java.CollHashSet;

public class Book
{
	private int number;
	private String title;
	private String author;
	private double cost;
	private int adition;
	private int noOfProgress;
	
	public Book(int number, String title, String author, double cost, int adition, int noOfProgress) {
		super();
		this.number = number;
		this.title = title;
		this.author = author;
		this.cost = cost;
		this.adition = adition;
		this.noOfProgress = noOfProgress;
	}
	@Override
	public String toString() {
		return "Book [number=" + number + ", title=" + title + ", author=" + author + ", cost=" + cost + ", adition="
				+ adition + ", noOfProgress=" + noOfProgress + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + adition;
		result = prime * result + ((author == null) ? 0 : author.hashCode());
		long temp;
		temp = Double.doubleToLongBits(cost);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + noOfProgress;
		result = prime * result + number;
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		if (adition != other.adition)
			return false;
		if (author == null) {
			if (other.author != null)
				return false;
		} else if (!author.equals(other.author))
			return false;
		if (Double.doubleToLongBits(cost) != Double.doubleToLongBits(other.cost))
			return false;
		if (noOfProgress != other.noOfProgress)
			return false;
		if (number != other.number)
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}
}
