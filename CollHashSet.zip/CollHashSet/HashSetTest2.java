package com.java.CollHashSet;

import java.util.HashSet;

//equal(),finalize(),clone(),hashCode(),wait wait wait,notify(),notifyAll();
//you can not decide your future ,you can decide your habit,and habit decide your future
public class HashSetTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Book bookObj1=new Book(101,"JPL","James Ghosling",1200,4, 900);
	Book bookObj2=new Book(101,"JPL","James Ghosling",1200, 4, 900);
	System.out.println("bookObj1 is: "+bookObj1.hashCode());
	System.out.println("bookObj2 is: "+bookObj2.hashCode());
	Book bookObj3=bookObj1;
	Book bookObj4=bookObj2;
	System.out.println("bookObj3 is: "+bookObj3.hashCode());
	System.out.println("bookObj4 is: "+bookObj4.hashCode());
	Book bookObj5=new Book(101,"JPL","James Ghosling",1200,4, 900);
	Book bookObj6=new Book(101,"JPL","James Ghosling",1200,4, 900);
	System.out.println("bookObj5:"+bookObj5.hashCode());
	System.out.println("bookObj6 "+bookObj6.hashCode());
	HashSet<Book> bookShelf=new HashSet<Book>();
	bookShelf.add(bookObj1);
	bookShelf.add(bookObj2);
//	bookShelf.add(bookObj3);
//	bookShelf.add(bookObj4);
	bookShelf.add(bookObj5);
	bookShelf.add(bookObj6);
	
	for (Book book : bookShelf)
	{
		System.out.println("The book is: "+book);
	}
	}	
}