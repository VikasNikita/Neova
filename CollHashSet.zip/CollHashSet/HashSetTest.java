package com.java.CollHashSet;

import java.util.HashSet;

public class HashSetTest {

	public static void main(String[] args) {
		HashSet<Integer> hashSet=new HashSet<Integer>();
		hashSet.add(10);
		hashSet.add(20);
		hashSet.add(30);
		hashSet.add(40);
		hashSet.add(50);
		
		for (Integer integer : hashSet)
		{
			System.out.println("The Number is: "+integer);
		}
	}

}