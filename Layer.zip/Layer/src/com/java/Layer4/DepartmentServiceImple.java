package com.java.Layer4;

import java.util.List;

import com.java.Layer2.Department;
import com.java.Layer3.DepartmentDAOImple;

public class DepartmentServiceImple implements DepartmentService
{

		DepartmentDAOImple deptDAO=new  DepartmentDAOImple();
		public DepartmentServiceImple()
		{
			System.out.println("Department Service IMpl: Constructor");
		}
	@Override
	public void createDepartmentService(Department dobj)
	{
		System.out.println("Create Department Service :createDepartmentService");
		System.out.println();
		deptDAO.insertDepartment(dobj);
		System.out.println("DepartmentServiceImplementation: createDepartment");
	}
	
	@Override
	public List<Department> findAllDepartsService() {
		return deptDAO.selectDepartments();
	}

	

}
