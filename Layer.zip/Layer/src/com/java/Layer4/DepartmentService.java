package com.java.Layer4;

import java.util.List;

import com.java.Layer2.Department;

public interface DepartmentService
{
	void createDepartmentService(Department dobj);
	List<Department> findAllDepartsService();
}
