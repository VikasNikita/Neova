package com.java.Layer3;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.java.Layer2.Department;

public class DepartmentDAOImple implements DepartmentDAO
{
	Connection conn;
	public DepartmentDAOImple() 
	{
		try {
			System.out.println("DepartmentDAOImpl : loading the driver .....getting the connection....");
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver Registered...........");
			conn=DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/mydb","SA","");
			System.out.println("Connected...."+conn);
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	@Override
	public void insertDepartment(Department dobj) {
		// TODO Auto-generated method stub
		System.out.println("Insert DepartmentDAOIMple: DepartmentDAOIMPLE");
		try {
			PreparedStatement pst=conn.prepareStatement("insert into dept values(? ,? ,?)");
			pst.setInt(1,dobj.getDepartmentNumber());
			pst.setString(2, dobj.getDepartmentName());
			pst.setString(3, dobj.getDepartmentLocation());
			int rows=pst.executeUpdate();
			System.out.println("Row created: "+rows);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@Override
	public Department selectDepartment(int dno)
	{
		System.out.println("Select DepartmentDAOIMple: DepartmentDAOIMPLE");

		return null;
	}

	@Override
	public List<Department> selectDepartments()
	{
		List<Department> deptList=new ArrayList<Department>();
		System.out.println("select Departments DepartmentDAOIMple: DepartmentDAOIMPLE");
		try {
			System.out.println("DepartmentDAOImple: select all department");
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery("select * from Department");
			while(rs.next())
			{
				Department dept=new Department();
				dept.setDepartmentNumber(rs.getInt(1));
				dept.setDepartmentName(rs.getString(2));
				dept.setDepartmentLocation(rs.getString(3));
				deptList.add(dept);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return deptList;
	}

	@Override
	public void updateDepartment(Department dObj) {
		System.out.println("update DepartmentDAOIMple: DepartmentDAOIMPLE");

	}

	@Override
	public void deleteDepartment(int dno) {
		System.out.println(" DepartmentDAOIMple: DepartmentDAOIMPLE");

	}

}
