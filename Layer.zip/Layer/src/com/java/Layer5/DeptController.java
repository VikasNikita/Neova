package com.java.Layer5;

import java.util.List;

import com.java.Layer2.Department;
import com.java.Layer4.DepartmentServiceImple;

public class DeptController 
{
	public static void main(String[] args) 
	{
		DepartmentServiceImple departmentServiceImple=new DepartmentServiceImple();
		
		Department deptObj=new Department();
	/*	
		deptObj.setDepartmentNumber(55);
		deptObj.setDepartmentName("Food");
		deptObj.setDepartmentLocation("Pune");
		*/
		List<Department> deptList=departmentServiceImple.findAllDepartsService();
		for(Department theDept: deptList)
		{
			System.out.println("Dept no :"+theDept.getDepartmentNumber());
			System.out.println("Dept no :"+theDept.getDepartmentName());
			System.out.println("Dept no :"+theDept.getDepartmentLocation());
			System.out.println("---------------------------------------------");
		}
	
		
	}
}
