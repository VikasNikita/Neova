package com.java.CollTreeSet;
//HeadFirstJavas
//jamesGhoslin
public class ChemicalElement implements Comparable<ChemicalElement>
{
	private int automicNumber;
	private String automicName;
	private  String autominFormula;
	private int autominWeight;
	public ChemicalElement(int automicNumber, String automicName, String autominFormula, int autominWeight) {
		super();
		this.automicNumber = automicNumber;
		this.automicName = automicName;
		this.autominFormula = autominFormula;
		this.autominWeight = autominWeight;
	}
	
	@Override
	public String toString() {
		return "ChemicalElement [automicNumber=" + automicNumber + ", automicName=" + automicName + ", autominFormula="
				+ autominFormula + ", autominWeight=" + autominWeight + "]";
	}
	/*
	@Override
	public int compareTo(ChemicalElement o)
	{
		System.out.println("Comparing "+automicNumber+" "+"with"+" "+o.automicNumber);
		return Integer.compare(automicNumber, o.automicNumber);
	}
	*/
	
	@Override
	public int compareTo(ChemicalElement o)
	{
		System.out.println("Comparing "+autominFormula+" "+"with"+" "+o.autominFormula);
		return autominFormula.compareTo(o.autominFormula);
	}
	
	
	
	
}
