package com.java.CollTreeSet;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetTest 
{
	public static void main(String[] args) 
	{
		TreeSet<Integer> integers=new TreeSet<Integer>();
		System.out.println("Container is ready.........");
		System.out.println("Adding first element");
		integers.add(12);
		System.out.println("Adding second element");
		integers.add(90);
		System.out.println("Adding third element");
		integers.add(10);
		System.out.println("Adding fourth element");
		integers.add(9);
		System.out.println("Adding fifth element");
		integers.add(23);
		System.out.println("Additing all element to the conatiner");
		
		Iterator<Integer> iterator=integers.iterator();
		
		while(iterator.hasNext())
		{
			System.out.println("Number is: "+iterator.next());
		}
	}
}
