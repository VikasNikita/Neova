package DeadLock;

public class Abcd {
	 synchronized  public void method1(Abcd obj) {
	   System.out.println("in method 1");
	   try {
		Thread.sleep(1000);
	} catch (Exception e) {
		
	}
	   obj.method2();
   }
 synchronized public void method2() {
	System.out.println("in method 2");
	
}
   
   
}
