package DeadLock;

public class Thread1 extends Thread{
    Abcd obj1;
    Abcd obj2;
	public Thread1(Abcd obj1, Abcd obj2) {
		super();
		this.obj1 = obj1;
		this.obj2 = obj2;
	}
	public void run() {
		obj1.method1(obj2);
		
	}
 
}
