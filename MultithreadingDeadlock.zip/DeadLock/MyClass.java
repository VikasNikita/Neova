package DeadLock;

public class MyClass {

	public static void main(String[] args) {
		Abcd obj1=new Abcd ();
		Abcd obj2=new Abcd();
		
		Thread1 t1=new Thread1 (obj1, obj2);
		Thread2 t2= new Thread2(obj1, obj2);
		t1.start();
		t2.start();
	}

}
