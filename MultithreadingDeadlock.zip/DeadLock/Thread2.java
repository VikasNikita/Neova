package DeadLock;

public class Thread2 extends Thread{
    Abcd obj1;
    Abcd obj2;
	public Thread2(Abcd obj1, Abcd obj2) {
		super();
		this.obj1 = obj1;
		this.obj2 = obj2;
	}
	public void run() {
		obj2.method1(obj1);
		
	}
 
}
