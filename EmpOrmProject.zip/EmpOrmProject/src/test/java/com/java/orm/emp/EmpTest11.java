package com.java.orm.emp;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class EmpTest11 {

	@Test
	public void testInsertEmp() {
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("entity manager factory : "+entityManagerFactory);
		
		
		Assertions.assertNotNull(entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("entity manager : "+entityManager);
		
		Assertions.assertNotNull(entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		
		Assertions.assertNotNull(transaction);
		
		System.out.println("transaction : "+transaction);
		
		transaction.begin();
		System.out.println("Transaction started....");
		
				Employee emp = new Employee();
				System.out.println("POJO created...");
				
				emp.setEmployeeId(371);
				emp.setEmployeeName("Julia");
				emp.setEmployeeSalary(13999);
				System.out.println("POJO filled up..");
				
				entityManager.persist(emp);
				System.out.println("Persited...");
				
		transaction.commit();
		System.out.println("Committed...");
	}
	
	@Test
	public void deptUpdateTest() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("entity manager factory : "+entityManagerFactory);
		
		
	Assertions.assertNotNull(entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("entity manager : "+entityManager);
		
	Assertions.assertNotNull(entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		
	Assertions.assertNotNull(transaction);
		
		System.out.println("transaction : "+transaction);
		
		transaction.begin();
		System.out.println("Transaction started....");
		
		Employee emp = null;
		System.out.println("null POJO created...");

		emp = entityManager.find(Employee.class,371);
		
		Assertions.assertNotNull(emp);
		
		System.out.println("EMPID : "+emp.getEmployeeId());
		System.out.println("EMPNAME : "+emp.getEmployeeName());
		System.out.println("EMPSALARY:"+emp.getEmployeeSalary());
		
		emp.setEmployeeName("Nikita");
		emp.setEmployeeSalary(2000);
		
		entityManager.merge(emp); // it will fire update query
		
		
		
		System.out.println("GOT THE POJO FROM DB..");
		System.out.println("RETRIEVED...");
		
		transaction.commit();
		System.out.println("Committed...");
				
		
	}
	@Test
	public void deptDeleteTest() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("entity manager factory : "+entityManagerFactory);
		
		
	Assertions.assertNotNull(entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("entity manager : "+entityManager);
		
	Assertions.assertNotNull(entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		
	Assertions.assertNotNull(transaction);
		
		System.out.println("transaction : "+transaction);
		
		transaction.begin();
		System.out.println("Transaction started....");
		
		Employee emp = null;
		System.out.println("null POJO created...");

		emp = entityManager.find(Employee.class,371);
		
	Assertions.assertNotNull(emp);
		
		System.out.println("DEPTNO : "+emp.getEmployeeId());
		System.out.println("DNAME  : "+emp.getEmployeeName());
		System.out.println("DLOC   : "+emp.getEmployeeSalary());
	
		entityManager.remove(emp); // it will fire update query
		
		
		
		System.out.println("GOT THE POJO FROM DB..");
		System.out.println("RETRIEVED...");
		
		transaction.commit();
		System.out.println("Committed...");
				
		
	}
	@Test
	public void deptSelectTest() {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("entity manager factory : "+entityManagerFactory);
		
		
	Assertions.assertNotNull(entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("entity manager : "+entityManager);
		
	Assertions.assertNotNull(entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		
	Assertions.assertNotNull(transaction);
		
		System.out.println("transaction : "+transaction);
		
		transaction.begin();
		System.out.println("Transaction started....");
		
		Employee emp = null;
		System.out.println("null POJO created...");

		emp = entityManager.find(Employee.class,371);
		
	Assertions.assertNotNull(emp);
		
		System.out.println("DEPTNO : "+emp.getEmployeeId());
		System.out.println("DNAME  : "+emp.getEmployeeName());
		System.out.println("DLOC   : "+emp.getEmployeeSalary());
		
		System.out.println("GOT THE POJO FROM DB..");
		System.out.println("RETRIEVED...");
		
		transaction.commit();
		System.out.println("Committed...");
				
		
	}
	
	
}
