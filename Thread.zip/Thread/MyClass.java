package Thread;

public class MyClass {

	public static void main(String[] args)  {
		Thread1 t1=new Thread1();
		Thread3 t3=new Thread3();
	    t1.start();
	    t3.start();
	   
	 //   Thread.sleep(1000);
	   // System.out.println("Task complete");
	    
		

	}

}
