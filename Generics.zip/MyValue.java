package com.java.container;

class MyValue<AnyType>
{
	public AnyType x;
	public AnyType y;
	public MyValue(AnyType x,AnyType y)
	{
		super();
		this.x=x;
		this.y=y;
	}
	void swap()
	{
		System.out.println("Swapping........");
		AnyType temp=x;
		x= y;
		y= temp;
	}
	public void print() 
	{
		System.out.println("x"+ x);
		System.out.println("y"+ y);
	}
}

