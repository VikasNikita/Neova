package com.java.container;

public class MyValueTest {

	public static void main(String[] args) {
		MyValue mi=new MyValue (10, 'A');
		mi.print();
		mi.swap();
		mi.print();
		
		
		
	}

}
