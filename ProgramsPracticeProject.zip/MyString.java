package com.java.container;

class MyString
{
	public String str;
	public String str1;
	public MyString(String str,String str1)
	{
		super();
		this.str=str;
		this.str1=str1;
	}
	void swap()
	{
		System.out.println("Swapping........");
		String temp=str;
		str=str1;
		str1=temp;
	}
	public void print() 
	{
		System.out.println("x"+ str);
		System.out.println("y"+ str1);
	}
}
 