package com.java.container;



public class IntegerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyInteger integer=new MyInteger(2, 9);
		integer.print();
		integer.swap();
		integer.print();
		System.out.println("___________________");
		MyFloat integer1=new MyFloat(1.3f, 1.9f);
		integer1.print();
		integer1.swap();
		integer1.print();
		System.out.println("_________________");
		MyString myString=new MyString("Core", "Java");
		myString.print();
		myString.swap();
		myString.print();
		
		Song song=new Song("xyz", "abcd", "pqrs", 2020);
		System.out.println(song);
		Song song2=new Song("lllll", "aaaaa"," bbbbb", 999); 
		System.out.println(song2);
		MyJukebox jukebox=new MyJukebox(song, song2);
		jukebox.print();
		jukebox.swap();
		jukebox.print();
		
	}

}
