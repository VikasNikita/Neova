package com.java.container;

class MyInteger
{
	public int x;
	public int y;
	public MyInteger(int x,int y)
	{
		super();
		this.x=x;
		this.y=y;
	}
	void swap()
	{
		System.out.println("Swapping........");
		int temp=x;
		x=y;
		y=temp;
	}
	public void print() 
	{
		System.out.println("x"+ x);
		System.out.println("y"+ y);
	}
}
 
