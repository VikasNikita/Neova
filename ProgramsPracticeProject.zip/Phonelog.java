package com.java.container;

import java.time.LocalDateTime;

public class Phonelog 
{
	String who;
	LocalDateTime date;
	String what;
	public Phonelog(String who,String what, LocalDateTime date) {
		super();
		this.who = who;
		this.date = date;
		this.what = what;
	}
	@Override
	public String toString() {
		return "Phonelog [who=" + who + ", date=" + date + ", what=" + what + "]";
	}
	
	
}
