package com.java.container;

public class MyJukebox
{
	Song s1;
	Song s2;
	public MyJukebox(Song s1,Song s2)
	{
		super();
		
		this.s1=s1;
		this.s2=s2;
		
	}
	void swap()
	{
		System.out.println("Swapping........");
		Song temp=s1;
		s1=s2;
		s2=temp;
	}
	public void print() 
	{
		System.out.println("x"+ s1);
		System.out.println("y"+ s2);
	}

 
}
