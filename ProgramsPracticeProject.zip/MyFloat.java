package com.java.container;

class MyFloat
{
	public float x;
	public float y;
	public MyFloat(float x,float y)
	{
		super();
		this.x=x;
		this.y=y;
	}
	void swap()
	{
		System.out.println("Swapping........");
		float temp=x;
		x=y;
		y=temp;
	}
	public void print() 
	{
		System.out.println("x"+ x);
		System.out.println("y"+ y);
	}
}
