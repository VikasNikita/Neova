package com.java;

public class Test {

	public static void main(String[] args) {
		Pistone pistone=new Pistone("TwineSpark");
		Engine engine=new Engine(pistone);
		Car theCar=new Car(engine);
		
		theCar.startCar();
	}

}
