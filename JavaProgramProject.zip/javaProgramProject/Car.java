package com.java;

public class Car
{
	Engine theEngine;
	public Car(Engine engine) {
		System.out.println("Car Starting....................");
		theEngine=engine;
	}
	public void startCar()
	{
		theEngine.start();
		System.out.println("Starting car................");
	}
}
