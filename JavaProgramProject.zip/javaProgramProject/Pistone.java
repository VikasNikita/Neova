package com.java;

public class Pistone
{
	String string;
	
	public Pistone(String str)
	{
		System.out.println("The piston Constructor");
		string=str;
	}
	public void firing() 
	{
		System.out.println("Firing..............");
	}
}
