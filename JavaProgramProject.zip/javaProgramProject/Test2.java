package com.java;

public class Test2 {

	public static void main(String[] args) {
		Car car=CarFactory.getCar();
		car.startCar();
		
		System.out.println(".............................................");
		
		Car car1=CarFactory.getCar();
		car1.startCar();
		
		
	}

}
