package com.java;

public class CarFactory
{
	public static  Car getCar()
	{
		Pistone pistone=new Pistone("TwineSpark");
		Engine engine=new Engine(pistone);
		Car car=new Car(engine);
		return car;
	}
}
