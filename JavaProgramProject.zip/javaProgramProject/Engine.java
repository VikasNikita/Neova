package com.java;

public class Engine 
{
	Pistone thePistone;
	public Engine(Pistone piston)
	{
		thePistone=piston;
		System.out.println("Engine Constructor....................");
	}
	public void start() 
	{
		thePistone.firing();
		System.out.println("Starting Engine.................");
	}
}
